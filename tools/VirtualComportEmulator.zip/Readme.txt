1. Execute vspd.exe to install this software (do execute it)
2. unzip "VirtualSerialPortDriver_Cracked.zip" and replace the files that have been installed in your system.
3. execute this software~


name: Bjorn Krangnes
registeration code:0000QN-RX7CTP-XGRBQ4-1D0G26-V7U5V8-F8NYHF